

<?php $__env->startSection('content'); ?>
<div class="row text-center">
    <div>
        <h2>Detalles Rol</h2>
        <a href="<?php echo e(route('user.index')); ?>" class="btn btn-primary">Volver</a>
    </div>
</div>

<div class="class m-5">
    <h3>Id usuario: <?php echo e($user->useId); ?></h3>
    <h3>Id rol: <?php echo e($user->rolId); ?></h3>
    <h4>Tipo documento: <?php echo e($user->useTipoDoc); ?></h4>
    <h4>Numero documento: <?php echo e($user->useNumDoc); ?></h4>
    <h4>Nombre-Apellido: <?php echo e($user->name); ?></h4>
    <h4>Corre electronico: <?php echo e($user->email); ?></h4>
    <h4>Telefono: <?php echo e($user->useTelefono); ?></h4>
    <h4>Verficacion correo electronico: <?php echo e($user->email_verified_at); ?></h4>
    <h4>Contraseña: <?php echo e($user->password); ?></h4>
    <h4>Token: <?php echo e($user->remember_token); ?></h4>
    <h4>Creacion del usuario: <?php echo e($user->created_at); ?></h4>
    <h4>Actualizacion del usuario: <?php echo e($user->updated_at); ?></h4>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel3\CrudProject\resources\views/user/show.blade.php ENDPATH**/ ?>