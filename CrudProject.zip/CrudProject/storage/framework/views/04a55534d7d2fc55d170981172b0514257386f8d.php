

<?php $__env->startSection('content'); ?>

<div class="row text-center">
    <div>
        <a href="<?php echo e(route('cliente.create')); ?>" class="btn btn-primary">Crear cliente</a>
    </div>
</div>

<!-- <?php if(session('success')): ?>
    <h6 class="alert alert-success p-2 mt-2" ><?php echo e(session('success')); ?></h6>
<?php endif; ?> -->

<?php if(Session::get('success')): ?>
    <div class="alert alert-success p-2 mx-5 my-2">
        <strong><?php echo e(Session::get('success')); ?></strong>
    </div>
<?php endif; ?>

<div class="col-md-10 m-4" >
    <table class="table table-bordered">
        <tr>
            <th>Id cliente</th>
            <th>Id rol</th>
            <th>Fecha Registro</th>
            <th></th>
        </tr>

        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td><?php echo e($cli->cliId); ?></td>
            <td><?php echo e($cli->rolId); ?></td>
            <td><?php echo e($cli->cliFechaRegistro); ?></td>
            <td>
                <a href="<?php echo e(route('cliente.show', $cli->cliId)); ?>" class="btn btn-info">Detalles</a>
                <a href="<?php echo e(route('cliente.edit', $cli->cliId)); ?>" class="btn btn-warning">Editar</a>

                <form action="<?php echo e(route('cliente.destroy', $cli->cliId)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel3\CrudProject\resources\views/cliente/index.blade.php ENDPATH**/ ?>