

<?php $__env->startSection('content'); ?>
<div class="row text-center">
    <div>
        <h2>Crear Rol</h2>
        <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-primary">Volver</a>
    </div>
</div>

<div class="container w-50 border p-4 mt-4">
    <form action="<?php echo e(route('roles.store')); ?>" method="POST" novalidate>
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="">Nombre rol:</label>
            <input id="" type="text" name="rolNombre" class="form-control" placeholder="Administrador">
        </div>
        <div class="mb-3">
            <label for="">Descripcion:</label>
            <input id="" type="text" name="rolDescripcion" class="form-control" placeholder="" >
        </div>
        <button type="submit" class="btn btn-primary">Crear rol</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel3\CrudProject\resources\views/rol/create.blade.php ENDPATH**/ ?>