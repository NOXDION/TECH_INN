

<?php $__env->startSection('content'); ?>
<div class="row text-center">
    <div>
        <h2>Crear Rol</h2>
        <a href="<?php echo e(route('usuarios.create')); ?>" class="btn btn-primary">Crear</a>
    </div>
</div>

<?php if(Session::get('success')): ?>
    <div class="alert alert-success p-2 mx-5 my-2">
        <strong><?php echo e(Session::get('success')); ?></strong>
    </div>
<?php endif; ?>

<div class="col-md-10 m-4">
    <table class="table table-bordered">
        <tr class="text-secondary">
            <th>Id usuario</th>
            <th>Id rol</th>
            <th>Tipo documento</th>
            <th>Numero Documento</th>
            <th>Nombre-Apellido</th>
            <th>Correo electronico</th>
            <th>Telefono</th>
            <th>Contraseña</th>
            <th></th>
        </tr>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="fw-bold"><?php echo e($user->useId); ?></td>
            <td><?php echo e($user->rolId); ?></td>
            <td><?php echo e($user->useTipoDoc); ?></td>
            <td><?php echo e($user->useNumDoc); ?></td>
            <td><?php echo e($user->name); ?></td>
            <td><?php echo e($user->email); ?></td>
            <td><?php echo e($user->useTelefono); ?></td>
            <td><?php echo e($user->password); ?></td>
            <td>
                <a href="<?php echo e(route('usuarios.show', $user->useId)); ?>" class="btn btn-info">Deatalles</a>
                <a href="<?php echo e(route('usuarios.edit', $user->useId)); ?>" class="btn btn-warning">Editar</a>

                <form action="<?php echo e(route('usuarios.destroy', $user->useId)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel3\CrudProject\resources\views/user/index.blade.php ENDPATH**/ ?>