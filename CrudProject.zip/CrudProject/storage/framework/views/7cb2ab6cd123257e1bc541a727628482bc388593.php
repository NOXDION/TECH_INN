

<?php $__env->startSection('content'); ?>
<div class="row text-center">
    <div>
        <h2>Crear Rol</h2>
        <a href="<?php echo e(route('rol.create')); ?>" class="btn btn-primary">Crear</a>
    </div>
</div>

<?php if(Session::get('success')): ?>
    <div class="alert alert-success p-2 mx-5 my-2">
        <strong><?php echo e(Session::get('success')); ?></strong>
    </div>
<?php endif; ?>

<div class="col-md-10 m-4">
    <table class="table table-bordered">
        <tr class="text-secondary">
            <th>Id rol</th>
            <th>Nombre rol</th>
            <th>Descripcion</th>
            <th></th>
        </tr>
        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="fw-bold"><?php echo e($rol->rolId); ?></td>
            <td><?php echo e($rol->rolNombre); ?></td>
            <td><?php echo e($rol->rolDescripcion); ?></td>
            <td>
                <a href="<?php echo e(route('rol.show', $rol->rolId)); ?>" class="btn btn-info">Detalles</a>
                <a href="<?php echo e(route('rol.edit', $rol->rolId)); ?>" class="btn btn-warning">Editar</a>

                <form action="<?php echo e(route('rol.destroy', $rol->rolId)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Aprendiz\Music\TechInn\CrudProject\resources\views/rol/index.blade.php ENDPATH**/ ?>