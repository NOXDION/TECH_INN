

<?php $__env->startSection('content'); ?>

<div class="container w-50 border p-4 mt-4">
  <form action="<?php echo e(route('cliente.store')); ?>" method="POST" novalidate>
    <?php echo csrf_field(); ?>
    <div class="mb-3">
      <label for="">Rol del Susodicho:</label>
      <input id="" type="number" name="rolId" class="form-control">
    </div>

    <div class="mb-3">
      <label for="" class="form-label">Fecha de registro del Susodicho:</label>
      <input id="" type="date" name="cliFechaRegistro" class="form-control">
    </div>

    <div class="d-flex">
      <button type="submit" class="btn btn-primary">Enviar</button>

      <div class="row">
        <div>
          <a href="<?php echo e(route('cliente.index')); ?>" class="btn btn-danger">Volver</a>
        </div>
      </div>
    </div>

  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel3\CrudProject\resources\views/cliente/create.blade.php ENDPATH**/ ?>