

<?php $__env->startSection('content'); ?>

<div class="row text-center">
    <div>
        <h2>Detalles</h2>
        <a href="<?php echo e(route('cliente.index')); ?>" class="btn btn-primary">Volver</a>
    </div>
</div>

<div class="m-5">
    <h3 style="color:blue">Id rol: </h3>
        <h5><?php echo e($cliente->rolId); ?></h5>
    <h3 style="color:blue">Fecha de registro: </h3>
        <h5><?php echo e($cliente->cliFechaRegistro); ?></h5>
    <h3 style="color:blue">Fecha de creacion: </h3>
        <h5><?php echo e($cliente->created_at); ?></h5>
    <h3 style="color:blue">Fecha de actualizacion: </h3>
        <h5><?php echo e($cliente->updated_at); ?></h5>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel3\CrudProject\resources\views/cliente/show.blade.php ENDPATH**/ ?>