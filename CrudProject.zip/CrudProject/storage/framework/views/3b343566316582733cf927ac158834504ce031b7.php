

<?php $__env->startSection('content'); ?>
<div class="row text-center">
    <div>
        <h2>Detalles Rol</h2>
        <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-primary">Volver</a>
    </div>
</div>

<div class="class m-5">
    <h3>Id rol: <?php echo e($rol->rolId); ?></h3>
    <h3>Nombre rol: <?php echo e($rol->rolNombre); ?></h3>
    <h4>Descripcion rol: <?php echo e($rol->rolDescripcion); ?></h4>
    <h4>Creacion del rol <?php echo e($rol->created_at); ?></h4>
    <h4>Actualizacion del rol <?php echo e($rol->updated_at); ?></h4>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel3\CrudProject\resources\views/rol/show.blade.php ENDPATH**/ ?>