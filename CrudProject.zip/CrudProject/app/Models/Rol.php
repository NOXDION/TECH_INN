<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rol extends Model
{
    use HasFactory;

    protected $table = 'tbRoles';

    protected $primaryKey = 'rolId';

    protected $fillable = [
        'rolNombre',
        'rolDescripcion',
    ];

    public function rol(){
        return $this->belongsTo(Rol::class, 'rolId', 'rolId');
    }
}
